import * as firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyAPhM9Q_XGMX7xaXMQHvSDJrVbWuZkDZNY",
  authDomain: "react-native-app-251a2.firebaseapp.com",
  projectId: "react-native-app-251a2",
  storageBucket: "react-native-app-251a2.appspot.com",
  messagingSenderId: "797532891125",
  appId: "1:797532891125:web:a70f32aa7a2027173262bc",
  measurementId: "G-Z83XKCBLGB"
};
   

  export default firebaseConfig;